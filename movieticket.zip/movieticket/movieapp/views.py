from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Upcoming, Trending, Book
from .forms import RegForm
from movieticket import settings
from .models import *
from django.contrib import messages
from django.contrib.auth import login as auth_login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm

def index(request):
    m = Trending.objects.all()
    return render(request,'index.html',{'m':m})

def upcoming(request):
    m1 = Upcoming.objects.all()
    return render(request,'upcoming.html',{'m':m1})

def trending(request):
    m2 = Trending.objects.all()
    return render(request,'trending.html',{'m':m2})

    
def booked(request):
    ob= Book.objects.all()
    return render(request,'booked.html',{'ob':ob})

def about(request):
    return render(request,'Untitled-1.html')

def details(request,id):
    d=Trending.objects.get(id=id)
    return render(request,'details.html',{'d':d})

def updetails(request,id):
    d=Upcoming.objects.get(id=id)
    return render(request,'updetails.html',{'d':d})

def login_page(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            auth_login(request,user)
            return redirect('/')
        else:
            messages.info(request,'Username and password is not right')      
    return render(request, "loginform.html")

def register(request):
    if request.user.is_authenticated:
        return redirect('/')
    else:
     form = RegForm(request.POST)
     if form.is_valid():
         form.save()
         user = form.cleaned_data.get('username')
         messages.success(request,'Account was created for '+ user)
         return redirect('login')
     context={'form':form}
     return render(request,'register.html',context)
    

@login_required(login_url="/login/")
  

def aboutmore(request):
    return render(request,'about.html')

def news(request):
    return render(request,'news.html')

def payment(requst):
    return render(requst,'payment.html')
