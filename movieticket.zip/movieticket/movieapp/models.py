from django.db import models
from django.contrib.auth.models import User

class CustomUser(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE,null=True, blank=True)
    email = models.EmailField(unique=True)
    mobile = models.IntegerField(max_length=8)
   

    def __str__(self):
        return self.user.username 


class Trending(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to="pics", default="default.png")
    date = models.DateField()
    duration = models.CharField(max_length=50)
    type = models.CharField(max_length=50)
    language = models.CharField(max_length=50)
    rating = models.CharField(max_length=50)
    cast = models.TextField(max_length=100)
    trailer = models.CharField(max_length=100)
    up = models.BooleanField(default=False)
    price = models.IntegerField(default=0)

    def __str__(self):
        return self.name
    
class Upcoming(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to="pics", default="default.png")
    date = models.DateField()
    duration = models.CharField(max_length=50)
    type = models.CharField(max_length=50)
    language = models.CharField(max_length=50)
    rating = models.CharField(max_length=50)
    cast = models.TextField()
    trailer = models.CharField(max_length=100)
    up = models.BooleanField(default=False)
    price = models.IntegerField(default=0)

    def __str__(self):
        return self.name


class Book(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, null=True, blank=True)
    email = models.EmailField()
    name = models.CharField(max_length=100)
    Cid = models.IntegerField()
    mobile = models.CharField(max_length=15)
    price = models.DecimalField(max_digits=10, decimal_places=2, default=None) 

    def __str__(self):
        return self.name
    
class Ticket(models.Model):
    movie = models.ForeignKey(Trending, on_delete=models.CASCADE)
    seat_number = models.CharField(max_length=10)
    user_name = models.CharField(max_length=100)

    
    