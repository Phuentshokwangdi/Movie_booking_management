from django.contrib import admin
from movieapp.models import Trending, Book,Upcoming,CustomUser, Ticket

admin.site.register(Ticket)
admin.site.register(CustomUser)
admin.site.register(Upcoming)
admin.site.register(Trending)
admin.site.register(Book)